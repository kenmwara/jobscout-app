# JobScout brand assets &middot; v2.3

Everything here is generated. `tokens/brand.json` is the source of truth;
`tokens/brand.css` is derived from it. Never hand-edit a PNG.

## The two cuts

`mark/jobscout-mark.svg` — **plate-less**, indigo `#4865ff`, cropped by its own
invisible square. This is the mark. The plate is a derivative, used only where a
mark needs its own ground.

`mark/jobscout-mark-display.svg` — the **display cut**: the same eight dots with
nothing cut. Use it at **48px and above, with clear space around
it** — document covers, feature graphics, social cards, site heroes, pitch
decks, and fit states at card size.

Never use the display cut inside a plate, in a lockup, or below the floor.
Uncropped it collapses into a ring of dots at small size, and beside the
wordmark it reads light. At bearings 270 and 315 the two largest dots touch —
the sweep closing on itself. The crop hid that; the display cut owns it, and
that is the reason for the floor.

| File | Use |
|---|---|
| `mark/jobscout-mark.svg` | Primary. On cream or white. |
| `mark/jobscout-mark-reverse.svg` | On deep-ink and other dark surfaces. |
| `mark/jobscout-mark-mono.svg` | One ink, where indigo would compete. |
| `mark/jobscout-icon.svg` | App tile. Indigo on deep-ink, plate radius 5.6/24. |
| `mark/jobscout-icon-maskable.svg` | Play and launchers. Inset to the 68% safe zone. |
| `mark/jobscout-mark-<band>.svg` | Fit states: auto, ping, unsure, near-miss. |
| `mark/jobscout-mark-display.svg` | Display cut. Also `-reverse` and `-mono`. |
| `mark/jobscout-mark-display-<band>.svg` | Fit states, display cut. Easier to count — its best showing. |

## Geometry

Ring r=11.0 in a 24 box, eight bearings 45&deg; apart. Dot radii
graduate **clockwise from bearing 000**, smallest to largest:
`r = 2.275 + 0.2944i`, so 000 is 2.275 and 315 is
4.336. The four cardinals and the largest are cropped by the square;
the four intercardinals are whole. At 270 and 315 the two largest clear each
other by 0.04 units — they read as touching, and that is the top of the sweep.

## Wordmark

Newsreader 400 at opsz 72, converted to outlines — no font file needed to render
it. Deep-ink, cream and indigo cuts in `wordmark/`.

## Lockups

Mark square = 1.15 &times; wordmark cap height, centred on the cap band.
Gap = 0.42 &times; mark side. Clear space = 0.5 &times; mark side on every edge.
Minimum width for the horizontal lockup is 112px; below that use the mark alone,
which holds down to 16px.

## Regenerating

`python3 assets.py` rebuilds this whole tree from `rose.py`, `wordmark.py` and
`tokens/brand.json`.
