# Android launcher icon · Brand Kit v2.2

Copy `mipmap-*` and `values/ic_launcher_background.xml` into
`android/app/src/main/res/`, overwriting what is there. The manifest already
points at `@mipmap/ic_launcher`; no manifest change is needed unless
`android:roundIcon` is missing:

```xml
<application
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round" ...>
```

## What each layer is

| File | Layer | Notes |
|---|---|---|
| `values/ic_launcher_background.xml` | background | Flat deep-ink `#080331`. A colour, not a bitmap — crisper and smaller. |
| `mipmap-*/ic_launcher_foreground.png` | foreground | Indigo mark on transparent, 108dp canvas with the mark's square inside the 72dp safe zone (66.7%). |
| `mipmap-*/ic_launcher_monochrome.png` | monochrome | Same shape in black on transparent. Android 13+ themed icons tint it; without this the launcher falls back to a flat generated glyph. |
| `mipmap-*/ic_launcher.png` | legacy square | Pre-API-26 devices. Full tile, plate radius 5.6/24. |
| `mipmap-*/ic_launcher_round.png` | legacy round | Circular plate, mark inset to 82% so the mask never clips a dot. |

## Why the foreground is inset

An adaptive icon is 108dp but a launcher may mask it down to a 72dp circle and
can parallax the layers. Anything outside the inner 72dp can be cut. The mark's
own crop square is sized to that 72dp, so the four cardinals still read as cut
by the design rather than by the mask.

Densities: mdpi 108, hdpi 162, xhdpi 216, xxhdpi 324, xxxhdpi 432 px for the
108dp layers; 48/72/96/144/192 px for the legacy icons.
