# Web icons & manifest · Brand Kit v2.2

Copy `icons/` to `site/public/icons/` and `site.webmanifest` to
`site/public/site.webmanifest`, then paste `head-snippet.html` into the
document head.

## Why the manifest matters here

The site already ships a 192px icon with nothing referencing it, so Android's
"add to home screen" never sees a maskable icon and generates its own — usually
the tile squeezed inside a white circle. The manifest is what points a launcher
at `icon-maskable-*`, which is the cut that survives masking.

| Key | Value | Why |
|---|---|---|
| `background_color` | `#f8f3eb` | Splash screen behind the icon. Canvas, not white. |
| `theme_color` | `#080331` | Browser chrome and the Android status bar. Deep-ink. |
| `purpose: any` | `icon-192`, `icon-512` | Drawn as-is; the plate's own corners show. |
| `purpose: maskable` | `icon-maskable-*` | Inset to the 68% safe zone so a launcher mask never halves a dot. |

Both purposes are needed. Shipping only `maskable` makes the icon look
small and over-padded in contexts that don't mask; shipping only `any` gets it
cropped in contexts that do.

`favicon.svg` is the vector tile — modern browsers prefer it and it stays sharp
on any tab density. The PNG faviconss stay for older ones.
